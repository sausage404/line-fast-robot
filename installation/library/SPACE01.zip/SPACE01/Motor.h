
#define PH1 3
#define EN1 5 

#define PH2 2 
#define EN2 6 

void Motor1(int Pow) {
  bool dir = (Pow >= 0 ? true : false);
  Pow = abs(Pow);
  Pow = (Pow * 255) / 100;
  digitalWrite(PH1, dir);
  analogWrite(EN1, Pow);
}

void Motor2(int Pow) {
  bool dir = (Pow >= 0 ? true : false);
  Pow = abs(Pow);
  Pow = (Pow * 255) / 100;
  digitalWrite(PH2, dir);
  analogWrite(EN2, Pow);
}

void Motor(int leftsp, int rightsp) {
  Motor1(leftsp);
  Motor2(rightsp);
}

void Move(int l, int r, int deelay) {
  Motor(l, r);
  delay(deelay);
}

void MotorStop() {
  Motor(0,0);
  delay(5);
}