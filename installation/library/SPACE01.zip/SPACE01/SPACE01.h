#include "Motor.h"
#define NUM_SENSORS 8
#define OK_PIN 4
#define BUZZER_PIN 8
#define PRESS 0

void Beep(int delayb) {
  tone(BUZZER_PIN, 900, delayb);
  delay(delayb);
  noTone(BUZZER_PIN);
}

void RobotSetup() {
  Serial.begin(115200);
  pinMode(PH1, OUTPUT);
  pinMode(EN1, OUTPUT);  \
  pinMode(PH2, OUTPUT);
  pinMode(EN2, OUTPUT);
  Beep(100);
  delay(50);
  Beep(100);
}

int analog(int __ch) {
  if(__ch==0) return analogRead(A0);
  if(__ch==1) return analogRead(A1);
  if(__ch==2) return analogRead(A2);
  if(__ch==3) return analogRead(A3);
  if(__ch==4) return analogRead(A4);
  if(__ch==5) return analogRead(A5);
  if(__ch==6) return analogRead(A6);
  if(__ch==7) return analogRead(A7);
}

void OK() {
  while (1) {
    if (digitalRead(OK_PIN) == PRESS) {
      break;
    }
  }
  Beep(100);
  delay(300);
}

int OK_PUSH() {
  if (digitalRead(OK_PIN) == PRESS) return PRESS;
  else {
    return 1;
  }
}
